package com.safetybus.pc.safetybus2.control;

import java.util.ArrayList;

import com.safetybus.pc.safetybus2.face.OnibusInterface;
import com.safetybus.pc.safetybus2.model.OnibusModel;

public class OnibusControl implements OnibusInterface {
    @Override
    public void CadastrarOnibus(OnibusModel onibus) {

    }

    @Override
    public void RemoverOnibus(OnibusModel onibus) {

    }

    @Override
    public ArrayList<OnibusModel> ConsutarOnibus(OnibusModel onibus) {
        return null;
    }
}
