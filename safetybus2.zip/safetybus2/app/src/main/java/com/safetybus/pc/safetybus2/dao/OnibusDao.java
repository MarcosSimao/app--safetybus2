package com.safetybus.pc.safetybus2.dao;

import java.util.ArrayList;

import com.safetybus.pc.safetybus2.face.OnibusInterface;
import com.safetybus.pc.safetybus2.model.OnibusModel;

public class OnibusDao implements OnibusInterface {
    @Override
    public void CadastrarOnibus(OnibusModel onibus) {

    }

    @Override
    public void RemoverOnibus(OnibusModel onibus) {

    }

    @Override
    public ArrayList<OnibusModel> ConsutarOnibus(OnibusModel onibus) {
        return null;
    }
}
